package core

type Features struct {
	Database bool
	Cache    bool
	GRPC     bool
}
